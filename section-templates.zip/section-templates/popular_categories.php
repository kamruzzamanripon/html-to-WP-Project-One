
<!--Category Section-->
<section class="category-section">
    <div class="auto-container">
        <!--Sec Title-->
        <div class="sec-title centered">
            <h2><?php echo __('Popular Categories', 'dizital'); ?></h2>
        </div>
        <div class="row clearfix">

			<?php
                $single_cat_ID = get_cat_ID( 'categories' );
                $single_cats   = get_categories( "parent=$single_cat_ID" );

                $single_query  = new WP_Query;

                foreach ( $single_cats as $single_cat ) :

                $single_query->query( array(
                    'cat'                 => $single_cat->term_id,
                    'posts_per_page'      => 1,
                    'category__not_in'    =>array(15, 14),
                    /*'category__in'      =>array(6,9,8,10,12,7,13,5,4,3),*/
                    'no_found_rows'       => true,
                    'ignore_sticky_posts' => true,
                ));
            ?>
	                <?php while ( $single_query->have_posts() ) : $single_query->the_post() ?>
                            <!--Category Block-->
                            <div class="category-block">
                                <div class="inner-box">

                                    <div class="image">
										<?php the_post_thumbnail('thumbnail')?>

                                        <div class="overlay-box">
                                            <div class="overlay-inner">
                                                <div class="content">
                                                    <h3><a href="<?php the_permalink(); ?>"> <?php echo $single_cat->name; ?> </a></h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

            <?php
                endwhile;
			    endforeach;
                wp_reset_query();
            ?>




        </div>
    </div>
</section>
<!--End Category Section-->
