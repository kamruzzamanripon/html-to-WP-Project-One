<?php
global $dizital_section;
$dizital_section_meta = get_post_meta($dizital_section['section'], 'dizital-counter-section', true);
$dizital_counter_img = wp_get_attachment_image_src($dizital_section_meta['image'], 'full');
?>

<!--Counter Section-->
<section class="counter-section">
	<!--Title Box-->
	<div class="title-box" style="background-image: url(<?php echo esc_url($dizital_counter_img[0]); ?>)">
		<div class="auto-container">
			<h2><?php echo esc_html($dizital_section_meta['heading']); ?></h2>
		</div>
	</div>
	<!--Lower Section-->
	<div class="lower-section">
		<div class="auto-container">

			<!--Fact Counter-->
			<div class="fact-counter">
				<div class="row clearfix">

                <?php
                foreach ($dizital_section_meta['counter'] as $dizital_counter_meta):
                ?>

                    <!--Column-->
					<div class="column counter-column col-lg-4 col-md-6 col-sm-12">
						<div class="inner">
							<div class="content">
								<div class="count-outer count-box">
									<span class="count-text" data-speed="<?php echo esc_attr($dizital_counter_meta['data_speed']); ?>" data-stop="<?php echo esc_attr($dizital_counter_meta['data_stop']); ?>">0</span>
								</div>
								<h4 class="counter-title"><?php echo esc_html($dizital_counter_meta['name_title']); ?></h4>
							</div>
						</div>
					</div>

                <?php endforeach; ?>

                </div>

			</div>

		</div>
	</div>
</section>
<!--End Counter Section-->