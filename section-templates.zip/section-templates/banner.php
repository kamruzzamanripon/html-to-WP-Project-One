<?php
global $dizital_section;
$dizital_section_meta = get_post_meta( $dizital_section['section'], 'dizital-section-banner', true );

$dizital_banner_image_id = $dizital_section_meta['image'];
if ( $dizital_banner_image_id ) {
	$dizital_banner_image = wp_get_attachment_image_src( $dizital_banner_image_id, 'dizital-fullsize' );
} else {
	$dizital_banner_image = array( get_template_directory_uri() . '/assets/images/background/1.jpg' );
}


?>

<!--Banner Section-->
<section class="banner-section" style="background-image: url(<?php echo $dizital_banner_image[0]; ?>)">
    <div class="auto-container">
        <h2><?php echo esc_html( $dizital_section_meta['heading'] ); ?></h2>
        <!--Search Form-->
        <div class="search-form">

            <div class="form-group clearfix">
				<?php
				$my_search = new WP_Advanced_Search( 'myform' );
				$my_search->the_form();
				?>

            </div>
            <div id="wpas-results"></div>
        </div>
        <!--End Search Form-->
        <div class="title"><?php echo esc_html( $dizital_section_meta['sub-heading'] ); ?></div>
    </div>
</section>
<!--End Banner Section-->