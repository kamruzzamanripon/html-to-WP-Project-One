<?php
$args = array(
	'posts_per_page' => 3,
	'tax_query' => array(
		'taxonomy' => 'category',
		'category__in' => array( 14 ),
	),
);

$post_query = new WP_Query( $args );

/*echo '<pre>';
print_r($post_query);
echo '<pre>';*/

?>

<!--News Section-->
<section class="news-section">
	<div class="auto-container">
		<div class="row clearfix">

			<?php while ( $post_query->have_posts() ) : $post_query->the_post() ?>
			<!--News Block-->
			<div class="news-block col-lg-4 col-md-6 col-sm-12">
				<div class="inner-box">
					<div class="post-date"><?php echo get_the_date('j. m. Y'); ?></div>
					<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
					<div class="text"><?php echo wp_trim_words(get_the_content(), 25, '.'); ?></div>
					<div class="author">
						<div class="author-image"><?php the_post_thumbnail('thumbnail')?></div>
						<?php echo __('by', 'dizital'); ?> <?php echo get_the_author(); ?>
					</div>
				</div>
			</div>


			<?php
			endwhile;
			wp_reset_query();
			?>



		</div>
	</div>
</section>
<!--End News Section-->
