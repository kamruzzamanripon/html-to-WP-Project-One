<?php
global $dizital_section;
$dizital_section_meta = get_post_meta($dizital_section['section'], 'dizital-portfolio-section', true);



?>

<!--Testimonial Section-->
<section class="testimonial-section">
	<div class="auto-container">
		<!--Sec Title-->
		<div class="sec-title centered">
			<h2><?php echo esc_html($dizital_section_meta['heading']); ?></h2>
		</div>
		<div class="three-item-carousel owl-carousel owl-theme">

			<?php
				foreach ($dizital_section_meta['portfolio'] as $dizital_testimonial_meta):
					$dizital_testimonial_meta_img = wp_get_attachment_image_src($dizital_testimonial_meta['image'], 'thumbnail');
			?>
			<!--Testimonial Block-->
			<div class="testimonial-block">
				<div class="inner-box">
					<div class="image">
						<img src="<?php echo $dizital_testimonial_meta_img[0]; ?>" alt="" />
					</div>
					<div class="text">“<?php echo esc_html($dizital_testimonial_meta['description']); ?>”</div>
					<h3><?php echo esc_html($dizital_testimonial_meta['name_title']); ?></h3>
					<div class="designation"><?php echo esc_html($dizital_testimonial_meta['designation']); ?></div>
				</div>
			</div>
			<?php endforeach; ?>

		</div>
	</div>
</section>
<!--End Testimonial Section-->