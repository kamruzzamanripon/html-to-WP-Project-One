
<!--Featured Section-->
<section class="featured-section">
    <div class="auto-container">
        <!--Sec Title-->
        <div class="sec-title centered">
            <h2><?php echo __('Feautured Items', 'dizital')?></h2>
        </div>
        <div class="row clearfix">

        <?php
            $get_post = new WP_Query(
                array(
                    'posts_per_page' => -1,
                    'post_type' => 'features',
                    'orderby' => 'menu_order',
                    'order' => 'ASC',
                )
            );
            while($get_post->have_posts()) : $get_post->the_post();
	            $dizital_feature_meta = get_post_meta( get_the_ID(), 'dizital-features-section', true );

        ?>


            <!--Featured Block-->
            <div class="featured-block col-lg-3 col-md-6 col-sm-12">
                <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                    <div class="image">
                        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('thumbnail')?></a>
                    </div>
                    <div class="lower-content">
                        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <div class="text"><?php echo wp_trim_words(get_the_content(), 15, '.'); ?></div>

        <?php

            if(!empty($dizital_feature_meta)):
                    $dizital_feature_img = wp_get_attachment_image_src($dizital_feature_meta['author_img'], 'thumbnail');
        ?>
                <div class="clearfix">
                        <div class="pull-left">
                                <div class="author">
                                    <div class="author-image"><img src="<?php echo $dizital_feature_img[0]; ?>" alt=""/></div>
                                    <?php echo __('by','dizital'); ?> <?php echo $dizital_feature_meta['author_name']; ?>
                                </div>
                            </div>
                            <div class="pull-right">
                                <div class="price"><?php echo __('$','dizital'); ?> <?php echo $dizital_feature_meta['author_price']; ?></div>
                            </div>
                        </div>
        <?php
            endif;
        ?>

                    </div>
                </div>
            </div>

        <?php endwhile; ?>
        </div>
    </div>
</section>








