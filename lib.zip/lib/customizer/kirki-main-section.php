<?php
if (class_exists( 'Kirki' )) {
	//configaration
	Kirki::add_config('dizital_options', array(
		'capability' => 'edit_theme_options',
		'option_type' => 'theme_mod',
	));

	//make panel
	Kirki::add_panel( 'dizital_pannel', array(
		'priority'    => 10,
		'title'       => esc_html__( 'Dizital Options', 'dizital' ),
	) );

	//make section
	Kirki::add_section( 'blog_settings', array(
		'title'          => esc_html__( 'Blog Settings', 'dizital' ),
		'panel'          => 'dizital_pannel',
		'priority'       => 160,
	) );


	//make field
	Kirki::add_field( 'dizital_options', [
		'type'        => 'select',
		'settings'    => 'sidebar_display_settings',
		'label'       => esc_html__( 'Single Page Sidebar Position', 'dizital' ),
		'section'     => 'blog_settings',
		'default'     => 'no',
		'priority'    => 10,
		'multiple'    => 1,
		'choices'     => [
			'no' => esc_html__( 'No sidebar', 'dizital' ),
			'left' => esc_html__( 'Left sidebar', 'dizital' ),
			'right' => esc_html__( 'Right sidebar', 'dizital' ),
		],
	] );

	//make field
	Kirki::add_field( 'dizital_options', [
		'type'        => 'select',
		'settings'    => 'sidebar_blog_settings',
		'label'       => esc_html__( 'Blog Sidebar Position', 'dizital' ),
		'section'     => 'blog_settings',
		'default'     => 'no',
		'priority'    => 10,
		'multiple'    => 1,
		'choices'     => [
			'no' => esc_html__( 'No sidebar', 'dizital' ),
			'left' => esc_html__( 'Left sidebar', 'dizital' ),
			'right' => esc_html__( 'Right sidebar', 'dizital' ),
		],
	] );


	
}