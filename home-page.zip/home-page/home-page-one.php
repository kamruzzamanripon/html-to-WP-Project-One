<?php
/*
* Template Name: dizital home page one
*/
get_header('one');

$dizital_sections = get_post_meta( get_the_ID(), 'dizital-page-section', true ); //inc/metaboxs/page-sections.php

if ( isset( $dizital_sections['sections'] ) && is_array($dizital_sections['sections']) ) {
	foreach ( $dizital_sections['sections'] as $dizital_section ) {
		$dizital_section_meta = get_post_meta( $dizital_section['section'], 'dizital-section-type', true );
		$dizital_section_type = isset( $dizital_section_meta['section-type'] ) ? $dizital_section_meta['section-type'] : '';

		get_template_part( "section-templates/{$dizital_section_type}" );
	}
}

get_footer();