<?php
/*
* Template Name: Price dizital page
*/
get_header();

$dizital_price_page_meta = get_post_meta(get_the_ID(), 'dizital-price-page', true);

$dizital_price_img_id = $dizital_price_page_meta['price_img'];
$dizital_price_img = wp_get_attachment_image_src($dizital_price_img_id, 'large');


?>
<!--Page Title-->
<section class="page-title" style="background-image: url(<?php echo esc_url($dizital_price_img[0]); ?>)">
	<div class="auto-container">
		<h1><?php the_title(); ?></h1>
		<div class="text"><?php echo esc_html($dizital_price_page_meta['price_banner_title']); ?></div>
	</div>
</section>
<!--End Page Title-->

<!--Price Page Section-->
<section class="price-page-section">
	<div class="auto-container">
		<div class="row clearfix">

			<?php
				$dizital_price_package = $dizital_price_page_meta['price_table'];
				foreach ($dizital_price_package as $dizital_price_package_list):
			?>
			<!--Price Block-->
			<div class="price-block col-lg-4 col-md-6 col-sm-12">
				<div class="inner-box">
					<div class="price"><?php echo __('$', 'dizital');?><?php echo esc_html($dizital_price_package_list['price_currency']);?></div>
					<h2><?php echo esc_html($dizital_price_package_list['package_name']);?></h2>

					<ul class="price-list">
						<?php
							$dizital_benefit_lists =  $dizital_price_package_list['benefit_table'];
							foreach ( $dizital_benefit_lists as $dizital_benefit_list):
						?>
						<li><?php echo esc_html($dizital_benefit_list['benefit_title']); ?></li>
						<?php
							endforeach;
						?>
					</ul>

					<a href="#" class="theme-btn btn-style-two">purchase</a>
				</div>
			</div>
			<?php
				endforeach;
			?>


		</div>
	</div>
</section>
<!--End Price Page Section-->

<?php
get_footer();