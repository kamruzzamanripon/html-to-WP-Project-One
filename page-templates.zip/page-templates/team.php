<?php
/*
* Template Name: Team dizital page
*/
get_header();

$dizital_team_meta = get_post_meta( get_the_ID(), 'dizital-team-page', true );

$dizital_team_img_id = $dizital_team_meta['team_img'];
$dizital_team_img    = wp_get_attachment_image_src( $dizital_team_img_id, 'large' );

/*echo '<pre>';
print_r($dizital_team_meta);
echo '</pre>';*/

?>
    <!--Page Title-->
    <section class="page-title" style="background-image: url(<?php echo esc_url( $dizital_team_img[0] ); ?>)">
        <div class="auto-container">
            <h1><?php the_title(); ?></h1>
            <div class="text"><?php echo esc_html( $dizital_team_meta['team_banner_title'] ); ?></div>
        </div>
    </section>
    <!--End Page Title-->

    <!--Team Page Section-->
    <section class="team-page-section">
        <div class="auto-container">
            <div class="row clearfix">

				<?php
				$dizital_team_tables         = $dizital_team_meta['team_table'];
				foreach ( $dizital_team_tables as $dizital_team_table ):
					$dizital_team_member_img_id = $dizital_team_table['team_table_img'];
					$dizital_team_member_img = wp_get_attachment_image_src( $dizital_team_member_img_id, 'full' );
					?>
                    <!--Team Block-->
                    <div class="team-block col-lg-3 col-md-6 col-sm-12">
                        <div class="inner-box">
                            <div class="image">
                                <a href="#"><img src="<?php echo esc_url( $dizital_team_member_img[0] ); ?>"
                                                 alt=""/></a>
                            </div>
                            <div class="lower-content">
                                <h3><a href="#"><?php echo esc_html( $dizital_team_table['name'] ); ?></a></h3>
                                <div class="designation"><?php echo esc_html( $dizital_team_table['designation'] ); ?></div>
                                <div class="text"><?php echo esc_html( $dizital_team_table['description'] ); ?></div>
                                <ul class="social-icon-one">
									<?php
									$dizital_social_iteams = $dizital_team_meta['team_social'];
									foreach ( $dizital_social_iteams as $dizital_social_iteam ):
										?>
                                        <li class="<?php echo esc_attr( $dizital_social_iteam['class'] ); ?>"><a
                                                    href="<?php echo esc_url( $dizital_social_iteam['link'] ); ?>"><span
                                                        class="fa <?php echo esc_html( $dizital_social_iteam['icon'] ); ?>"></span></a>
                                        </li>
									<?php
									endforeach;
									?>
                                </ul>
                            </div>
                        </div>
                    </div>
				<?php
				endforeach;
				?>


            </div>
        </div>
    </section>
    <!--End Team Page Section-->

<?php
get_footer();