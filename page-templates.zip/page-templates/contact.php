<?php
/*
* Template Name: Contact dizital page
*/
get_header();

$contact_page_meta = get_post_meta(get_the_ID(), 'dizital-contact-page', true);
$contact_img_id = $contact_page_meta['contact_img'];
if(!empty($contact_img_id)){
    $contact_img = wp_get_attachment_image_src($contact_img_id, 'large');
}else{
	$contact_img =array();
}

?>
<!--Page Title-->
<section class="page-title" style="background-image: url(<?php echo esc_url($contact_img[0]); ?>)">
	<div class="auto-container">
		<h1><?php the_title(); ?></h1>
		<div class="text"><?php echo esc_html($contact_page_meta['contact_banner_title']); ?></div>
	</div>
</section>
<!--End Page Title-->

<!--Contact Page Section-->
<section class="contact-page-section">
	<div class="auto-container">
		<div class="row clearfix">

			<!--Form Column-->
			<div class="form-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">
					<h2><?php echo __('Leave A Reply', 'dizital');?></h2>

					<!--Contact Form-->
					<div class="contact-form">

						<?php
                          echo do_shortcode('[contact-form-7 id="168" title="Contact form 1"]')
                        ?>

					</div>

				</div>
			</div>

			<!--Map Column-->
			<div class="map-column col-lg-6 col-md-12 col-sm-12">
				<div class="inner-column">

					<!--Map Info Section-->
					<section class="map-section">

                        <div class="map-canvas"
						    <!--Map Canvas-->
                            <iframe src="<?php echo esc_url($contact_page_meta['gmap_link']); ?>" frameborder="0"></iframe>
                        </div>
					</section>
					<!--End Map Info Section-->

				</div>
			</div>

		</div>
	</div>
</section>
<!--End Contact Page Section-->

<?php
get_footer();
?>