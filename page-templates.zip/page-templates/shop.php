<?php
/*
* Template Name: Shop dizital page
*/
get_header();

$dizital_shop_banner_meta = get_post_meta(get_the_ID(), 'dizital-shop-page', true);
$dizital_shop_banner_img_id = $dizital_shop_banner_meta['shop_banner_img'];
$dizital_shop_banner_img = wp_get_attachment_image_src($dizital_shop_banner_img_id, 'large');

$dizital_shop_offer_meta = get_post_meta(get_the_ID(), 'dizital-shop-offer', true);

$dizital_featured_meta = get_post_meta(get_the_ID(), 'dizital-featured-product', true);
$product_per_page = esc_html($dizital_featured_meta['product_number']);
?>
	<!--Page Title-->
	<section class="page-title" style="background-image: url(<?php echo esc_url($dizital_shop_banner_img[0]); ?>)">
		<div class="auto-container">
			<h1><?php echo esc_html($dizital_shop_banner_meta['shop_title']); ?></h1>
			<div class="text"><?php echo esc_html($dizital_shop_banner_meta['shop_banner_title']); ?></div>
		</div>
	</section>
	<!--End Page Title-->

	<!--Shop Features Section-->
	<section class="shop-features-section">
		<div class="auto-container">
			<div class="row clearfix">

				<?php
				$dizital_shop_offer_iteams = $dizital_shop_offer_meta['shop-offer'];
				foreach ($dizital_shop_offer_iteams as $dizital_shop_offer_iteam):
				?>
				<!--Feature Block-->
				<div class="feature-block-three col-lg-4 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="icon-box">
							<i class="<?php echo esc_attr($dizital_shop_offer_iteam['icon']); ?>"></i>
						</div>
						<h3><a href="#"><?php echo esc_html($dizital_shop_offer_iteam['title']); ?></a></h3>
						<div class="text"><?php echo apply_filters('the_content', $dizital_shop_offer_iteam['description']); ?></div>
					</div>
				</div>
				<?php
					endforeach;
				?>


			</div>
		</div>
	</section>
	<!--End Shop Features Section-->

	<!--Shop Page Section-->
	<section class="shop-page-section">
		<div class="auto-container">
			<div class="sec-title">
				<h2><?php echo esc_html($dizital_featured_meta['title']); ?></h2>
			</div>

			<div class="row clearfix">

				<?php
					$featured_agrs = array(
						 'post_type' => 'product',
						'posts_per_page' => $product_per_page,
						 'post_status' => 'publish'
					);

					$featured_query = new WP_Query($featured_agrs);
					while ($featured_query->have_posts()):
						$featured_query->the_post();

					$dizital_product_id = get_the_ID();
					$dizital_product = wc_get_product($dizital_product_id);
					$currency = get_woocommerce_currency_symbol();

					/*echo '<pre>';
					print_r($dizital_product);
					echo '</pre>';*/

				?>
				<!--Shop Item-->
				<div class="shop-item col-lg-3 col-md-6 col-sm-12">
					<div class="inner-box">
						<div class="image">
							<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
						</div>
						<div class="lower-content">
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
							<div class="price"><?php echo esc_html($currency); ?><?php echo $dizital_product->get_regular_price(); ?></div>
							<a href="/?add-to-cart=<?php echo $dizital_product_id; ?>" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart promo-more-btn theme-btn btn-style-two" data-product_id="<?php echo $dizital_product_id; ?>" data-product_sku="" aria-label="Add "<?php echo get_the_title( )?>"to your cart" rel="nofollow">
							<!--<a href="<?php /*echo home_url()."/?add-to-cart=" . get_the_ID(); */?>" class="theme-btn btn-style-two">--><?php _e( 'Add to cart', 'dizital' ); ?></a>
						</div>
					</div>
				</div>
				<?php
					endwhile;
					wp_reset_query();
				?>

			</div>

		</div>
	</section>
	<!--End Shop Page Section-->







<?php
get_footer();
