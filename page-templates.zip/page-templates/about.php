<?php
/*
* Template Name: about dizital page
*/
get_header();

$about_page_meta = get_post_meta(get_the_ID(), 'dizital-about-page', true);

$about_img_id = $about_page_meta['about_img'];
if($about_img_id){
	$about_img = wp_get_attachment_image_src($about_img_id, 'large');
}else{
	$about_img = array();
}

$about_signature_id = $about_page_meta['signature'];
if($about_signature_id){
	$about_signature = wp_get_attachment_image_src($about_signature_id, 'thumbnail');
}else{
	$about_signature = array();
}

while ( have_posts() ) :
	the_post();
?>

<!--Page Title-->
	<section class="page-title" style="background-image: url(<?php echo esc_url(($about_img[0])); ?>)">
		<div class="auto-container">
			<h1><?php the_title(); ?></h1>
			<div class="text"><?php echo esc_html($about_page_meta['auout_banner_title']); ?></div>
		</div>
	</section>
	<!--End Page Title-->

	<!--We Are Section-->
	<section class="we-are-section">
		<div class="auto-container">
			<div class="row clearfix">

				<!--Content Column-->
				<div class="content-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<h2><?php echo esc_html($about_page_meta['auout_title']); ?></h2>
						<!--<h4><?php /*echo apply_filters('the_content', $about_page_meta['auout_description']); */?></h4>-->
						<h5><?php the_content()?></h5>
                        <div class="signature"><img src="<?php echo esc_url(($about_signature[0])); ?>" alt="" /></div>
					</div>
				</div>

				<!--Image Column-->
				<div class="image-column col-lg-6 col-md-12 col-sm-12">
					<div class="inner-column">
						<div class="image">
							<?php the_post_thumbnail(); ?>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>
	<!--End We Are Section-->
<?php
endwhile;
get_footer();