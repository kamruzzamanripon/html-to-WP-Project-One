<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package dizital
 */

$dizital_sidebar_position = get_theme_mod( 'sidebar_blog_settings', 'no' );
$dizital_container_class  = 'no' == $dizital_sidebar_position ? 'masonry-item col-lg-4 col-md-6 col-sm-12' : '';
?>

<div class="news-block-two <?php echo esc_attr( $dizital_container_class ); ?>">
    <div class="inner-box">
        <div class="image">
			<?php dizital_post_thumbnail(); ?>
        </div>
        <div class="post-date"><?php echo get_the_date( 'j.m.Y' ); ?> </div>
        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

        <div class="entry-content">
            <div class="text">
				<?php
				the_content();

				wp_link_pages( array(
					'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'dizital' ),
					'after'  => '</div>',
				) );
				?>
            </div>
        </div><!-- .entry-content -->
		<?php if ( get_edit_post_link() ) : ?>

        <footer class="entry-footer">
			<?php
			edit_post_link(
				sprintf(
					wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
						__( 'Edit <span class="screen-reader-text">%s</span>', 'dizital' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					get_the_title()
				),
				'<span class="edit-link">',
				'</span>'
			);
			?>

            <div class="post-meta-option">
                <div class="author">
                    <div class="author-image"><img src="images/resource/author-2.jpg" alt=""/></div>
					<?php echo __( 'by', 'dizital' ); ?> <?php echo get_the_author(); ?>
                </div>
				<?php
				$dizital_tag = get_the_category();
				?>

                <ul class="post-meta">
                    <i class="fa fa-bookmark-o"></i>
					<?php
					if ( $dizital_tag ):
						foreach ( $dizital_tag as $dizital_tag_item ):
							printf( '<li><a href="%s">%s</a></li>', get_category_link( $dizital_tag_item ), $dizital_tag_item->name );
						endforeach;
					endif;
					?>
                </ul>
                <span> <i class="fa fa-comment-o"></i>
                    <?php echo get_comments_number(); ?></span>
            </div>
    </div>
</div>




<?php endif; ?>

