<?php
//Cs inisilization
define( 'CS_ACTIVE_FRAMEWORK', false ); // default true
define( 'CS_ACTIVE_METABOX', true ); // default true
define( 'CS_ACTIVE_TAXONOMY', false ); // default true
define( 'CS_ACTIVE_SHORTCODE', false ); // default true
define( 'CS_ACTIVE_CUSTOMIZE', false ); // default true

function dizital_csf_init() {
	CSFramework_Metabox::instance( array() );
}
add_action( 'init', 'dizital_csf_init' );

//meta seetions
require get_template_directory() . '/inc/metaboxs/section-part.php';
require get_template_directory() . '/inc/metaboxs/page-sections.php';
require get_template_directory() . '/inc/metaboxs/banner.php';
require get_template_directory() . '/inc/metaboxs/feature.php';
require get_template_directory() . '/inc/metaboxs/portfolio.php';
require get_template_directory() . '/inc/metaboxs/counter.php';
require get_template_directory() . '/inc/metaboxs/about-meta.php';
require get_template_directory() . '/inc/metaboxs/contact-meta.php';
require get_template_directory() . '/inc/metaboxs/price-meta.php';
require get_template_directory() . '/inc/metaboxs/team-meta.php';
require get_template_directory() . '/inc/metaboxs/shop-meta.php';