<?php
function demo_ajax_search() {
	$args = array();
	$args['wp_query'] = array( 'post_type' => array('book'),
	                           'orderby' => 'title',
	                           'order' => 'ASC' );

	$args['form'] = array( 'auto_submit' => true );

	$args['form']['ajax'] = array( 'enabled' => true,
	                               'show_default_results' => false,
	                               'results_template' => 'search-advance.php', // This file must exist in your theme root
	                               'button_text' => 'Load More Results');

	$args['fields'][] = array( 'type' => 'search',
	                           'placeholder' => 'Enter search terms and more' );


	$args['fields'][] = array( 'type' => 'taxonomy',
	                           'taxonomy' => 'book_type',
	                           'format' => 'select',
	                           'class' => 'custom-select-box',
	                           'operator' => 'AND',
	                            );

	$args['fields'][] = array( 'type' => 'submit',
	                           'class' => 'theme-btn dripicons-search',
	                           'value' => 'Search' );

	register_wpas_form('myform', $args);
}
add_action('init', 'demo_ajax_search');