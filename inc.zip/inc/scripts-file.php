<?php
/**
 * Enqueue scripts and styles.
 */
function dizital_scripts() {
	wp_enqueue_style('google-montserrat-font', '//fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i');
	wp_enqueue_style('animate', get_template_directory_uri() . '/assets/css/animate.css' );
	wp_enqueue_style('bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.css' );
	wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.css' );
	wp_enqueue_style('hover', get_template_directory_uri() . '/assets/css/hover.css');
	wp_enqueue_style('fancybox', get_template_directory_uri() . '/assets/css/jquery.fancybox.min.css');
	wp_enqueue_style('mcustomscrollbar', get_template_directory_uri() . '/assets/css/jquery.mCustomScrollbar.min.css');
	wp_enqueue_style('jquery-ui', get_template_directory_uri() . '/assets/css/jquery-ui.css');
	wp_enqueue_style('owl', get_template_directory_uri() . '/assets/css/owl.css');
	wp_enqueue_style('responsive', get_template_directory_uri() . '/assets/css/responsive.css');
	wp_enqueue_style('webfont', get_template_directory_uri() . '/assets/css/webfont.css');
	wp_enqueue_style('main', get_template_directory_uri() . '/assets/css/main.css');

	wp_enqueue_style( 'dizital-style');


	wp_enqueue_script( 'popper-js', get_template_directory_uri() . '/assets/js/popper.min.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '4.1.1', true );
	wp_enqueue_script( 'dizital-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), '20151215', true );
	wp_enqueue_script( 'dizital-skip-link-focus-fix', get_template_directory_uri() . '/assets/js/skip-link-focus-fix.js', array(), '20151215', true );
	wp_enqueue_script( 'isotope', get_template_directory_uri() . '/assets/js/isotope.js', array('jquery'), '1.1.1', true );
	wp_enqueue_script( 'jquery-easing', get_template_directory_uri() . '/assets/js/jquery.easing.min.js', array('jquery'), '1.1.1', true );
	wp_enqueue_script( 'jquery-easing', get_template_directory_uri() . '/assets/js/jquery.fancybox.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'm-custom-scrollbar', get_template_directory_uri() . '/assets/js/jquery.mCustomScrollbar.concat.min.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'm-custom-scrollbar', get_template_directory_uri() . '/assets/js/jquery.mCustomScrollbar.concat.min.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'jquery-ui', get_template_directory_uri() . '/assets/js/jquery-ui.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script('google-map', '//maps.googleapis.com/maps/api/js?key=AIzaSyCzwXEQUgGfA0cOi-WHMINHqtHBJVl3upg', array(), '1.0', true );
	wp_enqueue_script( 'map-script', get_template_directory_uri() . '/assets/js/map-script.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'mixitup', get_template_directory_uri() . '/assets/js/mixitup.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'owl', get_template_directory_uri() . '/assets/js/owl.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'respond', get_template_directory_uri() . '/assets/js/respond.js', array(), '1.0.0', true );
	wp_enqueue_script( 'skip-link', get_template_directory_uri() . '/assets/js/skip-link-focus-fix.js', array(), '1.0.0', true );
	wp_enqueue_script( 'validate', get_template_directory_uri() . '/assets/js/validate.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'wow', get_template_directory_uri() . '/assets/js/wow.js', array('jquery'), '1.0.0', true );
	wp_enqueue_script( 'script', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), '1.0.0', true );



	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'dizital_scripts' );