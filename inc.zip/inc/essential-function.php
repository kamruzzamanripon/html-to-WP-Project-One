<?php

//Search from re-arrange
function dizital_my_search_form($form){
	$home_dir = home_url('/');
	$ploce_holder = __('Search Here', 'dizital');
	$value = get_search_query();
	$form = '<form role="search" method="get" action="'.$home_dir.'">
			    <div class="form-group">
			        <input type="text" name="s" value="'.$value.'" placeholder="'.$ploce_holder.'" required="">
			        <button type="submit" class="search-btn"><i class="fa fa-search"></i></button>
			    </div>
			</form>';

	return $form;

}
add_filter('get_search_form', 'dizital_my_search_form');



//Woocommerce Comment from re-orginize
function woocommerce_form_customize($comment_form){
	$comment_form['comment_field'] = '<div class="row clearfix">
									<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<textarea id="comment" name="comment" placeholder="Comment..."></textarea>
									</div>';
	 $comment_form['fields']['author']= '<div class="col-lg-4 col-md-6 col-sm-12 form-group">
										<input type="text" id="author" name="author" placeholder="Name" required>
									</div>';

	$comment_form['fields']['email'] = '<div class="col-lg-4 col-md-6 col-sm-12 form-group">
										<input id="email" name="email" placeholder="Email" required>
									</div>';
	$comment_form['fields']['url'] = '<div class="col-lg-4 col-md-12 col-sm-12 form-group">
										<input type="text" id="url" name="url" placeholder="Website" required>
									</div>';
	$comment_form['submit_button'] = '<div class="col-lg-12 col-md-12 col-sm-12 form-group">
										<button class="theme-btn btn-style-two" type="submit" name="submit-form">Submit</button>
									</div>
									</div>';


	return $comment_form;

}
add_filter('woocommerce_product_review_comment_form_args', 'woocommerce_form_customize');


//Extra class add in li
/*function dizital_nav_menu_css_class($classes, $item, $args){

	if('menu-1'=== $args->theme_location){
		$classes[]="";
	}

	return $classes;


}
add_filter('nav_menu_css_class', 'dizital_nav_menu_css_class', 10, 3);*/



//Woocommerce
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );




