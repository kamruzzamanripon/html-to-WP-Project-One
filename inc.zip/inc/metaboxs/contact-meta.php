<?php

function dizital_contact_page_metabox($metaboxes){
	$page_id = 0;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$page_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	$current_page_template = get_post_meta($page_id,'_wp_page_template',true);
	if('page-templates/contact.php'!=$current_page_template){
		return $metaboxes;
	}

	$metaboxes[] = array(
		'id'=>'dizital-contact-page',
		'title'=>__('Contact Page Info','dizital'),
		'post_type'=>'page',
		'context'=>'normal',
		'priority'=>'default',
		'sections'=>array(
			array(
				'name'=>'dizital-contact-page-section',
				'icon'=>'fa fa-image',
				'fields'=>array(
					array(
						'id'        => 'contact_banner_title',
						'type'      => 'text',
						'title'     =>  __('Contact Banner Title', 'dizital'),
					),
					array(
						'id'        => 'contact_img',
						'type'      => 'image',
						'title'     =>  __('Contact Landscape Picture', 'dizital'),
					),
					array(
						'id'        => 'gmap_link',
						'type'      => 'text',
						'title'     =>  __('Gmap iframe link', 'dizital'),
					),

				)
			)
		)
	);
	return $metaboxes;
}
add_filter('cs_metabox_options','dizital_contact_page_metabox');
