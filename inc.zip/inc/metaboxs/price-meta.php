<?php

function dizital_price_page_metabox($metaboxes){
	$page_id = 0;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$page_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	$current_page_template = get_post_meta($page_id,'_wp_page_template',true);
	if('page-templates/price.php'!=$current_page_template){
		return $metaboxes;
	}

	$metaboxes[] = array(
		'id'=>'dizital-price-page',
		'title'=>__('Contact Page Info','dizital'),
		'post_type'=>'page',
		'context'=>'normal',
		'priority'=>'default',
		'sections'=>array(
			array(
				'name'=>'dizital-price-page-section',
				'icon'=>'fa fa-image',
				'fields'=>array(
					array(
						'id'        => 'price_banner_title',
						'type'      => 'text',
						'title'     =>  __('Price Banner Title', 'dizital'),
					),
					array(
						'id'        => 'price_img',
						'type'      => 'image',
						'title'     =>  __('Price Landscape Picture', 'dizital'),
					),
					array(
						'id'=>'price_table',
						'type'=>'group',
						'title'=>__('Price Package Table Sections','dizital'),
						'button_title'=>__('New Package','dizital'),
						'accordion_title'=>__('Add New Package','dizital'),
						'fields'=>array(
							array(
								'id'        => 'package_name',
								'type'      => 'text',
								'title'     =>  __('Package Name', 'dizital'),
							),
							array(
								'id'        => 'price_currency',
								'type'      => 'text',
								'title'     =>  __('Total Price', 'dizital'),
							),
							array(
								'id'        => 'benefit_table',
								'type'      => 'group',
								'title'     =>  __('Type of Benefit', 'dizital'),
								'button_title'=>__('Benefit','dizital'),
								'accordion_title'=>__('Add New Benefit','dizital'),
								'fields'=>array(
									array(
										'id'        => 'benefit_title',
										'type'      => 'text',
										'title'     =>  __('Benefit Title', 'dizital'),
										'default'     =>  __('Benefit Title', 'dizital'),
									)
								),
							),
						)
					),


				)
			)
		)
	);
	return $metaboxes;
}
add_filter('cs_metabox_options','dizital_price_page_metabox');
