<?php

function dizital_shop_page_metabox($metaboxes){
	$page_id = 0;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$page_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	$current_page_template = get_post_meta($page_id,'_wp_page_template',true);
	if('page-templates/shop.php'!=$current_page_template){
		return $metaboxes;
	}

	$metaboxes[] = array(
		'id'=>'dizital-shop-page',
		'title'=>__('Shop Info','dizital'),
		'post_type'=>'page',
		'context'=>'normal',
		'priority'=>'default',
		'sections'=>array(
			array(
				'name'=>'dizital-shop-page-section',
				'icon'=>'fa fa-image',
				'fields'=>array(
					array(
						'id'        => 'shop_title',
						'type'      => 'text',
						'title'     =>  __('shop Title', 'dizital'),
					),
					array(
						'id'        => 'shop_banner_title',
						'type'      => 'text',
						'title'     =>  __('Shop Banner Title', 'dizital'),
					),
					array(
						'id'        => 'shop_banner_img',
						'type'      => 'image',
						'title'     =>  __('Shop Banner Landscape Picture', 'dizital'),
					),



				)
			)
		),

	);

	$metaboxes[] = array(
		'id'=>'dizital-shop-offer',
		'title'=>__('Shop Offer Info','dizital'),
		'post_type'=>'page',
		'context'=>'normal',
		'priority'=>'default',
		'sections'=>array(
			array(
				'name'=>'dizital-shop-page-section',
				'icon'=>'fa fa-image',
				'fields'=>array(
					array(
						'id'        => 'shop-offer',
						'type'      => 'group',
						'title'     =>  __('Type of Benefit', 'dizital'),
						'button_title'=>__('Type of Benefit','dizital'),
						'accordion_title'=>__('Add New Benefit','dizital'),
						'fields'=>array(
							array(
								'id'        => 'title',
								'type'      => 'text',
								'title'     =>  __('offer Title', 'dizital'),
								'default'     =>  __('offer Title', 'dizital'),
							),
							array(
								'id'        => 'description',
								'type'      => 'textarea',
								'title'     =>  __('offer Description', 'dizital'),
								'default'     =>  __('offer Description', 'dizital'),
							),
							array(
								'id'        => 'icon',
								'type'      => 'icon',
								'title'     =>  __('offer icon', 'dizital'),
								'default'     =>  __('fa fa-star', 'dizital'),
							)
						),
					),

				),
			)
		),

	);

	$metaboxes[] = array(
		'id'=>'dizital-featured-product',
		'title'=>__('Featured product  Info','dizital'),
		'post_type'=>'page',
		'context'=>'normal',
		'priority'=>'default',
		'sections'=>array(
			array(
				'name'=>'dizital-featured-product-section',
				'icon'=>'fa fa-image',
				'fields'=>array(
					array(
						'id'        => 'title',
						'type'      => 'text',
						'title'     =>  __('Featured Title', 'dizital'),
					),
					array(
						'id'        => 'product_number',
						'type'      => 'text',
						'title'     =>  __('Product Number', 'dizital'),
					),

				)
			)
		),

	);
	return $metaboxes;
}
add_filter('cs_metabox_options','dizital_shop_page_metabox');
