<?php
/*
 *  if select home-page-one.php than show this meta box and this is home custome metabox that you can sortable
 */
function dizital_page_sections_metabox($metaboxes){
	$page_id = 0;

	//backend sourse/current page id show
	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$page_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	$current_page_template = get_post_meta($page_id,'_wp_page_template',true);
	if('home-page/home-page-one.php'!=$current_page_template){
		return $metaboxes;
	}

	$metaboxes[] = array(
		'id'=>'dizital-page-section',
		'title'=>__('Sections','dizital'),
		'post_type'=>'page',
		'context'=>'normal',
		'priority'=>'default',
		'sections'=>array(
			array(
				'name'=>'dizital-page-sections-section',
				'icon'=>'fa fa-image',
				'fields'=>array(
					array(
						'id'=>'sections',
						'type'=>'group',
						'title'=>__('Select Sections','dizital'),
						'button_title'=>__('New Section','dizital'),
						'accordion_title'=>__('Add New Section','dizital'),
						'fields'=>array(
							array(
								'id'=>'section',
								'type'=>'select',
								'title'=>__('Select Section','dizital'),
								'options'=>'post',
								'query_args'=>array(
									'post_type'=>'section',
									'posts_per_page'=>-1
								)
							)
						)
					),

				)
			)
		)
	);
	return $metaboxes;
}
add_filter('cs_metabox_options','dizital_page_sections_metabox');
