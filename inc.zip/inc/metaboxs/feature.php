<?php
function dizital_section_features_metabox($metaboxes){



	$metaboxes[] = array(
		'id'            =>  'dizital-features-section',
		'title'         =>  __('Sections', 'dizital'),
		'post_type'     =>  'features',
		'context'       =>  'normal',
		'priority'      =>  'default',
		'sections'      =>  array(
			array(
				'name'  =>  'dizital-features-sections',
				'icon'  =>  'fa fa-image',
				'fields'  =>  array(
					array(
						'id'        => 'author_name',
						'type'      => 'text',
						'title'     =>  __('Author Name', 'dizital'),
					),
					array(
						'id'        => 'author_img',
						'type'      => 'image',
						'title'     =>  __('Author Image', 'dizital'),
					),
					array(
						'id'        => 'author_price',
						'type'      => 'text',
						'title'     =>  __('Price', 'dizital'),
					),

				)
			)
		)
	);

	return $metaboxes;
}
add_filter('cs_metabox_options', 'dizital_section_features_metabox');