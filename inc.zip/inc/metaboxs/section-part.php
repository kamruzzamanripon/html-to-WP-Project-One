<?php
/*
 *  this meta show type of section in your custom post like as section
 */
function dizital_section_type_metabox($metaboxes){
	$metaboxes[] = array(
		'id'=>'dizital-section-type',
		'title'=>__('Section Type','dizital'),
		'post_type'=>'section',
		'context'=>'normal',
		'priority'=>'default',
		'sections'=>array(
			array(
				'name'=>'dizital-section-type-section',
				'icon'=>'fa fa-image',
				'fields'=>array(
					array(
						'id'=>'section-type',
						'type'=>'select',
						'title'=>__('Select Section Type','dizital'),
						'options'=>array(
							'banner'=>__('Banner','dizital'),
							'feature'=>__('Feature','dizital'),
							'popular_categories'=>__('popular categories','dizital'),
							'blog'=>__('Blog or News Section','dizital'),
							'portfolio'=>__('Portfolio or Happy Customer','dizital'),
							'counter'=>__('Counter','dizital'),
						)
					)
				)
			)
		)
	);
	return $metaboxes;
}
add_filter('cs_metabox_options','dizital_section_type_metabox');