<?php
function dizital_section_counter_metabox($metaboxes){

	$section_id = 0;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$section_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	if('section' != get_post_type($section_id)){  //'post_type' =>  'section' from sections.php file,
		return $metaboxes;
	}

	$section_meta = get_post_meta($section_id,'dizital-section-type',true);
	if(!$section_meta){
		return $metaboxes;
	}elseif ('counter' != $section_meta['section-type']){
		return $metaboxes;
	}

	$metaboxes[] = array(
		'id'            =>  'dizital-counter-section',
		'title'         =>  __('Sections', 'dizital'),
		'post_type'     =>  'section',
		'context'       =>  'normal',
		'priority'      =>  'default',
		'sections'      =>  array(
			array(
				'name'  =>  'dizital-counter-sections',
				'icon'  =>  'fa fa-image',
				'fields'  =>  array(
					array(
						'id'    => 'heading',
						'type'  => 'text',
						'title' =>  __('Counter Heading', 'dizital'),
						'default'=>  __('Our Work', 'dizital'),
					),
					array(
						'id'    => 'image',
						'type'  => 'image',
						'title' =>  __('Counter Image', 'dizital'),
					),
					array(
						'id'                 => 'counter',
						'type'              => 'group',
						'title'             => __('Counter', 'dizital'),
						'button_title'      => __('New Counter', 'dizital'),
						'accordion_title'   => __('Add New Counter', 'dizital'),
						'fields' => array(
							array(
								'id'        => 'name_title',
								'type'      => 'text',
								'title'     =>  __('Counter Title', 'dizital'),
							),
							array(
								'id'        => 'data_stop',
								'type'      => 'text',
								'title'     =>  __('When Data Stop', 'dizital'),
							),
							array(
								'id'        => 'data_speed',
								'type'      => 'text',
								'title'     =>  __('Data Speed Limit', 'dizital'),
							),

						)
					),

				)
			)
		)
	);

	return $metaboxes;
}
add_filter('cs_metabox_options', 'dizital_section_counter_metabox');