<?php

function dizital_team_page_metabox($metaboxes){
	$page_id = 0;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$page_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	$current_page_template = get_post_meta($page_id,'_wp_page_template',true);
	if('page-templates/team.php'!=$current_page_template){
		return $metaboxes;
	}

	$metaboxes[] = array(
		'id'=>'dizital-team-page',
		'title'=>__('Contact Page Info','dizital'),
		'post_type'=>'page',
		'context'=>'normal',
		'priority'=>'default',
		'sections'=>array(
			array(
				'name'=>'dizital-team-page-section',
				'icon'=>'fa fa-image',
				'fields'=>array(
					array(
						'id'        => 'team_banner_title',
						'type'      => 'text',
						'title'     =>  __('Team Banner Title', 'dizital'),
					),
					array(
						'id'        => 'team_img',
						'type'      => 'image',
						'title'     =>  __('Team Landscape Picture', 'dizital'),
					),
					array(
						'id'=>'team_table',
						'type'=>'group',
						'title'=>__('Team Table Sections','dizital'),
						'button_title'=>__('New Team','dizital'),
						'accordion_title'=>__('Add New Team','dizital'),
						'fields'=>array(
							array(
								'id'        => 'name',
								'type'      => 'text',
								'title'     =>  __('Name', 'dizital'),
							),
							array(
								'id'        => 'designation',
								'type'      => 'text',
								'title'     =>  __('Designation', 'dizital'),
							),
							array(
								'id'        => 'description',
								'type'      => 'text',
								'title'     =>  __('Description', 'dizital'),
							),
							array(
								'id'        => 'team_table_img',
								'type'      => 'image',
								'title'     =>  __('Team Member Picture', 'dizital'),
							),

						)
					),
					array(
						'id'=>'team_social',
						'type'=>'group',
						'title'=>__('Team Social Sections','dizital'),
						'button_title'=>__('New Social','dizital'),
						'accordion_title'=>__('Add New Social','dizital'),
						'fields'=>array(
							array(
								'id'        => 'link',
								'type'      => 'text',
								'title'     =>  __('social link', 'dizital'),
							),
							array(
								'id'        => 'icon',
								'type'      => 'text',
								'title'     =>  __('icon ex- fa-facebook', 'dizital'),
							),
							array(
								'id'        => 'class',
								'type'      => 'text',
								'title'     =>  __('icon class ex-facebook', 'dizital'),
							),


						)
					),


				)
			)
		)
	);
	return $metaboxes;
}
add_filter('cs_metabox_options','dizital_team_page_metabox');
