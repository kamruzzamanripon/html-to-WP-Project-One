<?php
function dizital_section_banner_metabox($metaboxes){

	$section_id = 0;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$section_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	} //Current page find

	if('section' != get_post_type($section_id)){  //'post_type' =>  'section' from sections.php file,
		return $metaboxes;
	}

	$section_meta = get_post_meta($section_id,'dizital-section-type',true); //dizital-section-type = Section Id
	if(!$section_meta){
		return $metaboxes;
	}elseif ('banner' != $section_meta['section-type']){
		return $metaboxes;
	}


	//$section_type = $section_meta['type'];
//	if('banner'!=$section_type){
//		return $metaboxes;
//	}


	$metaboxes[] = array(
		'id'            =>  'dizital-section-banner',
		'title'         =>  __('Banner Seeting', 'dizital'),
		'post_type'     =>  'section',
		'context'       =>  'normal',
		'priority'      =>  'default',
		'sections'      =>  array(
			array(
				'name'  =>  'dizital-section-type-banner',
				'icon'  =>  'fa fa-image',
				'fields'  =>  array(
					array(
						'id'    => 'image',
						'type'  => 'image',
						'title' =>  __('Banner Image', 'dizital'),
					),
					array(
						'id'    => 'heading',
						'type'  => 'text',
						'title' =>  __('Banner Heading', 'dizital'),
						'default'=>  __('Gain the Befautiful Result', 'dizital'),
					),
					array(
						'id'    => 'sub-heading',
						'type'  => 'text',
						'title' =>  __('Banner Sub-Heading or term', 'dizital'),
						'default'=>  __('Unlocking the next dimension in business analysis', 'dizital'),
					),

				)
			)
		)
	);

	return $metaboxes;
}
add_filter('cs_metabox_options', 'dizital_section_banner_metabox');