<?php

function dizital_about_page_metabox($metaboxes){
	$page_id = 0;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$page_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	$current_page_template = get_post_meta($page_id,'_wp_page_template',true);
	if('page-templates/about.php'!=$current_page_template){
		return $metaboxes;
	}

	$metaboxes[] = array(
		'id'=>'dizital-about-page',
		'title'=>__('About Page Info','dizital'),
		'post_type'=>'page',
		'context'=>'normal',
		'priority'=>'default',
		'sections'=>array(
			array(
				'name'=>'dizital-about-page-section',
				'icon'=>'fa fa-image',
				'fields'=>array(
					array(
						'id'        => 'auout_title',
						'type'      => 'text',
						'title'     =>  __('About Title', 'dizital'),
					),
					array(
						'id'        => 'auout_banner_title',
						'type'      => 'text',
						'title'     =>  __('About Banner Title', 'dizital'),
					),
					array(
						'id'        => 'auout_description',
						'type'      => 'textarea',
						'title'     =>  __('About Description', 'dizital'),
					),
					array(
						'id'        => 'about_img',
						'type'      => 'image',
						'title'     =>  __('About Landscape Picture', 'dizital'),
					),
					array(
						'id'        => 'signature',
						'type'      => 'image',
						'title'     =>  __('Signature', 'dizital'),
					),

				)
			)
		)
	);
	return $metaboxes;
}
add_filter('cs_metabox_options','dizital_about_page_metabox');
